import { shuffle } from './shuffle.js';
import { Game } from './game.js';
import { Rack } from './rack.js';

console.log(shuffle([1, 2, 3, 4, 5])); // this should produce a different sequence each time
let g = new Game();
let r = new Rack();
